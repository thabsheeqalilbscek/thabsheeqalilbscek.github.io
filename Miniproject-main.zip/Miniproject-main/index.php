<?php
  include_once 'header.php';
?>

  <section class="index-intro">
    <h1><b>FLIP</b></h1>
    <h2>WEB BASED NOTES APPLICATION</h2>
</section>