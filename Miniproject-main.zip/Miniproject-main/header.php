<!DOCTYPE html>
<html lang="en-uk" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name = "viewport" content="width=device-width, initial-scale=1.0">
        <title>Home page</title>
    </head>
 <body>
     
  <nav>
    <div class="wrapper">
        <a href="index.php"></a>
        <ul>
            <li><a href="index.php">HOME</a></ul>
            <li><a href="discover.php">ABOUT</a></ul>
            <li><a href="signup.php">SIGN UP</a></ul>
            <li><a href="login.php">LOGIN</a></ul>
        </ul>
    </div>
  </nav>

 </body>
</html>